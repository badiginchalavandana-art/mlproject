# Telco Customer Churn — EDA, Preprocessing & Class Imbalance Handling

## What's in here
```
churn_analysis/
├── data/                              ← put the CSV here
├── src/
│   └── churn_analysis.py              ← the analysis, in 3 parts
├── requirements.txt
└── README.md
```

## Setup in VSCode

1. Unzip the project and open the `churn_analysis` folder in VSCode.
2. Get the dataset — [WA_Fn-UseC_-Telco-Customer-Churn.csv](https://www.kaggle.com/datasets/blastchar/telco-customer-churn)
   (Kaggle) — and place it at `data/WA_Fn-UseC_-Telco-Customer-Churn.csv`.
3. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
4. Install the **Jupyter** extension in VSCode (Python extension usually
   pulls it in automatically).
5. Open `src/churn_analysis.py`. Each `# %%` marker is a runnable cell —
   click "Run Cell" above any block, or "Run All", to execute it in
   VSCode's Jupyter interactive window with inline plots.
   - Alternatively, run it as a plain script: `python src/churn_analysis.py`
     (plots will pop up in separate windows; tables print instead of
     rendering as HTML).

## What changed from the original snippet

The pasted code had a few issues that would stop it from running, now fixed:
- `num_cols` / `cat_cols` were used before being defined — added right
  after the initial load.
- Several `for` loops (box plots, KNN outlier detection/removal) had lost
  their indentation in the paste — restored so the loop bodies actually
  run.
- A stray trailing `)` at the very end caused a syntax error — removed.
- `display()` only exists in Jupyter; added a fallback to `print()` so
  the file also runs as a plain script.
- Added `# %%` cell markers so it works well with VSCode's Jupyter
  interactive window.

## Structure

- **Part 1 — EDA**: load, inspect, summary stats, correlation heatmap,
  churn distribution, histograms, box plots, pair plot.
- **Part 2 — Preprocessing**: missing-value analysis, several imputation
  strategies (row/column deletion, mean/median/mode, random sampling,
  KNN), outlier detection & removal (IQR), one-hot encoding, scaling.
- **Part 3 — Class imbalance handling**: train/test split, scaling
  (fit on train only), and three resampling strategies (upsampling,
  downsampling, SMOTE) stored in `sampling_data` for downstream modeling.
