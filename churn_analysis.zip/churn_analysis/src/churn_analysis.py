# %% [markdown]
# # Telco Customer Churn — EDA, Preprocessing & Class Imbalance Handling
#
# Run this file top-to-bottom in VSCode using the Jupyter extension
# (each `# %%` block is a runnable cell), or run it as a plain script:
# `python src/churn_analysis.py`
#
# Place the dataset at: `data/WA_Fn-UseC_-Telco-Customer-Churn.csv`

# %%
# ============================================================
# PART 0: SETUP
# ============================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

# `display()` only exists in Jupyter/IPython. This makes the script
# runnable both as notebook cells and as a plain .py file.
try:
    from IPython.display import display
except ImportError:
    display = print

DATA_PATH = "data/WA_Fn-UseC_-Telco-Customer-Churn.csv"

# %%
# ============================================================
# PART 1: DATASET LOADING & EXPLORATORY DATA ANALYSIS (EDA)
# ============================================================
df = pd.read_csv(DATA_PATH)

print("=" * 60)
print("DATASET LOADED SUCCESSFULLY")
print("=" * 60)

print("\nFirst 5 Records")
display(df.head())

print("\nLast 5 Records")
display(df.tail())

print("\nDataset Shape")
print("Rows :", df.shape[0])
print("Columns :", df.shape[1])

print("\nColumn Names")
print(df.columns.tolist())

print("\nDataset Information")
df.info()

print("\nData Types")
display(df.dtypes)

# TotalCharges is loaded as object (has blank strings) — coerce to numeric
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")

print("\nMissing Values")
display(df.isnull().sum())

print("\nDuplicate Rows :", df.duplicated().sum())

print("\nStatistical Summary")
display(df.describe())

# Define numeric / categorical column groups (used throughout the script)
num_cols = df.select_dtypes(include=np.number).columns
cat_cols = df.select_dtypes(include="object").columns

summary = pd.DataFrame({
    "Minimum": df.min(numeric_only=True),
    "Q1": df.quantile(0.25, numeric_only=True),
    "Median": df.median(numeric_only=True),
    "Q3": df.quantile(0.75, numeric_only=True),
    "Maximum": df.max(numeric_only=True),
})
print("\nFive Number Summary")
display(summary)

print("\nMean")
display(df.mean(numeric_only=True))

print("\nVariance")
display(df.var(numeric_only=True))

print("\nCategorical Columns")
print(cat_cols.tolist())

# %%
# --- Visualizations ---
plt.figure(figsize=(8, 6))
sns.heatmap(df[num_cols].corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Matrix")
plt.show()

plt.figure(figsize=(5, 4))
sns.countplot(x="Churn", data=df)
plt.title("Customer Churn Distribution")
plt.show()

print("\nChurn Percentage")
display(df["Churn"].value_counts(normalize=True) * 100)

df[num_cols].hist(figsize=(10, 6))
plt.tight_layout()
plt.show()

for col in num_cols:
    plt.figure(figsize=(5, 3))
    sns.boxplot(x=df[col])
    plt.title(col)
    plt.show()

sns.pairplot(df[num_cols])
plt.show()

print("\nRandom Sample")
display(df.sample(10))

# %%
# ============================================================
# PART 2: DATA PREPROCESSING
# ============================================================
print("=" * 60)
print("MISSING VALUES")
print("=" * 60)

missing = pd.DataFrame({
    "Missing Values": df.isnull().sum(),
    "Percentage": (df.isnull().sum() / len(df)) * 100,
})
display(missing[missing["Missing Values"] > 0])

print("\nMCAR : Missing Completely At Random")
print("MAR  : Missing At Random")
print("MNAR : Missing Not At Random")

# --- Strategy 1: Row deletion ---
df_row = df.dropna()
print("\nOriginal Shape :", df.shape)
print("After Row Deletion :", df_row.shape)

# --- Strategy 2: Column deletion above a missing-percentage threshold ---
threshold = 30
cols_drop = missing[missing["Percentage"] > threshold].index
df_column = df.drop(columns=cols_drop)
print("\nDropped Columns")
print(cols_drop.tolist())

# --- Strategy 3: Mean imputation ---
df_mean = df.copy()
for col in df_mean.select_dtypes(include=np.number).columns:
    df_mean[col] = df_mean[col].fillna(df_mean[col].mean())
print("\nMean Imputation Completed")

# --- Strategy 4: Median imputation ---
df_median = df.copy()
for col in df_median.select_dtypes(include=np.number).columns:
    df_median[col] = df_median[col].fillna(df_median[col].median())
print("Median Imputation Completed")

# --- Strategy 5: Mode imputation (all columns) ---
df_mode = df.copy()
for col in df_mode.columns:
    df_mode[col] = df_mode[col].fillna(df_mode[col].mode()[0])
print("Mode Imputation Completed")

# --- Strategy 6: Random sampling imputation ---
df_random = df.copy()
for col in df_random.select_dtypes(include=np.number).columns:
    missing_count = df_random[col].isnull().sum()
    if missing_count > 0:
        sample = df_random[col].dropna().sample(
            missing_count, replace=True, random_state=42
        ).values
        df_random.loc[df_random[col].isnull(), col] = sample
print("Random Sampling Imputation Completed")

# --- Strategy 7: KNN imputation (used going forward) ---
from sklearn.impute import KNNImputer

df_knn = df.copy()
knn_num_cols = df_knn.select_dtypes(include=np.number).columns
knn = KNNImputer(n_neighbors=5)
df_knn[knn_num_cols] = knn.fit_transform(df_knn[knn_num_cols])
print("KNN Imputation Completed")

print("\nDuplicate Rows :", df_knn.duplicated().sum())
df_knn = df_knn.drop_duplicates()
print("After Removing Duplicates :", df_knn.shape)

# --- Outlier detection (IQR method) ---
numeric = df_knn.select_dtypes(include=np.number).columns
for col in numeric:
    Q1 = df_knn[col].quantile(0.25)
    Q3 = df_knn[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = df_knn[(df_knn[col] < lower) | (df_knn[col] > upper)]
    print(col, "=", len(outliers), "Outliers")

# --- Outlier removal ---
df_no_outlier = df_knn.copy()
for col in numeric:
    Q1 = df_no_outlier[col].quantile(0.25)
    Q3 = df_no_outlier[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    df_no_outlier = df_no_outlier[
        (df_no_outlier[col] >= lower) & (df_no_outlier[col] <= upper)
    ]
print("\nShape After Removing Outliers")
print(df_no_outlier.shape)

# --- Encoding ---
df_encoded = pd.get_dummies(df_no_outlier, drop_first=True)
print("\nShape After Encoding")
print(df_encoded.shape)

# --- Feature scaling (fit on full encoded set, for reference only —
#     the real train/test-safe scaling happens in Part 3) ---
from sklearn.preprocessing import RobustScaler

TARGET = "Churn_Yes"
X = df_encoded.drop(TARGET, axis=1)
y = df_encoded[TARGET]

scaler = RobustScaler()
X_scaled = scaler.fit_transform(X)
print("\nFeature Scaling Completed")
print("Scaled Data Shape :", X_scaled.shape)

# %%
# ============================================================
# PART 3: CLASS IMBALANCE HANDLING
# ============================================================
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import RobustScaler
from imblearn.over_sampling import RandomOverSampler, SMOTE
from imblearn.under_sampling import RandomUnderSampler

# Features and Target
X = df_encoded.drop("Churn_Yes", axis=1)
y = df_encoded["Churn_Yes"]

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Feature Scaling (fit on train only, applied to test — avoids leakage)
scaler = RobustScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

sampling_data = {}
sampling_data["Original"] = (X_train, y_train)

# Upsampling
ros = RandomOverSampler(random_state=42)
X_up, y_up = ros.fit_resample(X_train, y_train)
sampling_data["Upsampling"] = (X_up, y_up)

# Downsampling
rus = RandomUnderSampler(random_state=42)
X_down, y_down = rus.fit_resample(X_train, y_train)
sampling_data["Downsampling"] = (X_down, y_down)

# SMOTE
smote = SMOTE(random_state=42)
X_smote, y_smote = smote.fit_resample(X_train, y_train)
sampling_data["SMOTE"] = (X_smote, y_smote)

print("Class Imbalance Handling Completed")
for name, (Xs, ys) in sampling_data.items():
    print(f"  {name}: X={Xs.shape}, y={ys.shape}, positive_rate={ys.mean():.3f}")
